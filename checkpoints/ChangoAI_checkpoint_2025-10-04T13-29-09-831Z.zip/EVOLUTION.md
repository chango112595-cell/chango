# Evolution
- v1.0 — HUD + client TTS
- v1.1 — Voice profiles, checkpoints, logs
- v1.2 — Dual-state hologram, curiosity core